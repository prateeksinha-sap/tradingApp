# 🎯 NiftyScout — Daily Nifty 50 Stock Picker

A locally-deployed Python app that analyses all Nifty 50 stocks and suggests the top 3 "no-brainer" picks for the day, based on a composite scoring model.

## What It Does

Every time you run it, NiftyScout:
1. Fetches end-of-day price/volume data for all 50 Nifty stocks (via Yahoo Finance)
2. Pulls fundamental data (P/E, debt, ROE, growth, beta)
3. Computes **4 dimension scores** (0–100 each) for every stock
4. Produces a **weighted composite score** and ranks all 50 stocks
5. Shows you the **top 3 picks** with detailed breakdowns, charts, and reasoning

## Scoring Model

| Dimension | Weight | What It Measures |
|-----------|--------|-----------------|
| **Technical** (25%) | RSI, MACD, SMA crossover, volume spike | Is the stock trending up with conviction? |
| **Fundamental** (25%) | P/E ratio, debt/equity, ROE, earnings growth | Is the company financially strong? |
| **Institutional** (25%) | OBV accumulation, price trend, dividend yield | Are big players buying? |
| **Risk Safety** (25%) | Beta, volatility, drawdown from 52-week high | How risky is this entry? |

Weights are adjustable via sliders in the sidebar.

## Setup (Windows)

### 1. Install Python
Download Python 3.10+ from [python.org](https://python.org). During install, check **"Add Python to PATH"**.

### 2. Clone / Download this project
Put the `nifty-scout` folder anywhere on your machine.

### 3. Open a terminal in the project folder
```
cd C:\path\to\nifty-scout
```

### 4. Create a virtual environment (recommended)
```
python -m venv venv
venv\Scripts\activate
```

### 5. Install dependencies
```
pip install -r requirements.txt
```

### 6. Run the app
```
streamlit run app.py
```

Your browser will open at `http://localhost:8501` with the dashboard.

## Daily Usage

Just run `streamlit run app.py` each day after market close (3:30 PM IST).
The app caches data to avoid redundant API calls.

Click **"Clear Cache & Refresh"** in the sidebar to force a fresh data pull.

## Project Structure

```
nifty-scout/
├── app.py              # Streamlit dashboard (main entry point)
├── config.py           # All settings, tickers, weights, thresholds
├── data_fetcher.py     # Yahoo Finance data download + SQLite caching
├── scoring.py          # The 4-dimension scoring engine
├── requirements.txt    # Python dependencies
├── data/               # SQLite cache (auto-created)
│   └── niftyscout.db
└── README.md
```

## Customisation

- **Change weights**: Use sidebar sliders, or edit `WEIGHTS` in `config.py`
- **Change stock universe**: Edit `NIFTY_50_TICKERS` in `config.py`
- **Adjust thresholds**: Tweak `TECH_CONFIG`, `FUND_CONFIG`, `RISK_CONFIG` in `config.py`
- **Add more indicators**: Extend `compute_technical_score()` in `scoring.py`

## Limitations & Disclaimer

- Data is **end-of-day** (not real-time) from Yahoo Finance
- Fundamental data from yfinance can occasionally be missing or stale
- FII/DII flow data is approximated via OBV (not actual exchange data)
- **This is NOT financial advice.** It's a decision-support tool. Always do your own research.

## Future Improvements

- [ ] Add actual FII/DII flow scraping from NSE/MoneyControl
- [ ] Add screener.in scraping for promoter holding data
- [ ] Backtesting module to validate the scoring model on historical data
- [ ] Telegram/email alerts for daily picks
- [ ] Broker API integration for real-time data
