"""
NiftyScout Configuration
All tuneable parameters in one place.
"""

# ── Nifty 50 Tickers (NSE symbols, yfinance format) ─────────────────────────
NIFTY_50_TICKERS = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
    "HINDUNILVR.NS", "ITC.NS", "SBIN.NS", "BHARTIARTL.NS", "KOTAKBANK.NS",
    "LT.NS", "AXISBANK.NS", "ASIANPAINT.NS", "MARUTI.NS", "HCLTECH.NS",
    "SUNPHARMA.NS", "TITAN.NS", "BAJFINANCE.NS", "WIPRO.NS", "ULTRACEMCO.NS",
    "NESTLEIND.NS", "ONGC.NS", "NTPC.NS", "POWERGRID.NS", "M&M.NS",
    "TATAMOTORS.NS", "ADANIENT.NS", "ADANIPORTS.NS", "JSWSTEEL.NS", "TATASTEEL.NS",
    "TECHM.NS", "INDUSINDBK.NS", "BAJAJFINSV.NS", "HINDALCO.NS", "COALINDIA.NS",
    "GRASIM.NS", "CIPLA.NS", "DRREDDY.NS", "EICHERMOT.NS", "DIVISLAB.NS",
    "APOLLOHOSP.NS", "BPCL.NS", "HEROMOTOCO.NS", "TATACONSUM.NS", "BRITANNIA.NS",
    "SBILIFE.NS", "HDFCLIFE.NS", "BAJAJ-AUTO.NS", "WIPRO.NS", "SHRIRAMFIN.NS",
]

# De-duplicate (WIPRO appears twice in some lists)
NIFTY_50_TICKERS = list(dict.fromkeys(NIFTY_50_TICKERS))

# ── Scoring Weights (must sum to 1.0) ────────────────────────────────────────
WEIGHTS = {
    "technical":    0.25,   # RSI, MACD, MA crossover, volume spike
    "fundamental":  0.25,   # P/E, debt/equity, promoter holding
    "institutional":0.25,   # FII/DII flow alignment, delivery %
    "risk":         0.25,   # Beta, volatility, drawdown from 52w high
}

# ── Technical Indicator Thresholds ────────────────────────────────────────────
TECH_CONFIG = {
    "rsi_period":        14,
    "rsi_oversold":      30,    # Below this → bullish signal
    "rsi_overbought":    70,    # Above this → bearish signal
    "rsi_sweet_spot":    (40, 65),  # Ideal zone for momentum
    "macd_fast":         12,
    "macd_slow":         26,
    "macd_signal":       9,
    "sma_short":         20,
    "sma_long":          50,
    "volume_spike_threshold": 1.5,  # 1.5x average volume = notable
    "lookback_days":     100,       # Trading days of history to fetch
}

# ── Fundamental Thresholds ────────────────────────────────────────────────────
FUND_CONFIG = {
    "pe_max":            40,    # Exclude stocks with P/E above this
    "pe_ideal":          20,    # Below this scores highest
    "debt_equity_max":   1.5,   # Exclude highly leveraged companies
    "min_market_cap_cr": 10000, # ₹10,000 Cr minimum (all Nifty 50 qualify)
}

# ── Risk Thresholds ──────────────────────────────────────────────────────────
RISK_CONFIG = {
    "max_beta":          1.5,
    "ideal_beta":        (0.7, 1.2),
    "max_drawdown_pct":  25,    # Max acceptable drawdown from 52w high
    "volatility_window": 20,    # Days to measure recent volatility
}

# ── Data Cache Settings ──────────────────────────────────────────────────────
CACHE_CONFIG = {
    "db_path":            "data/niftyscout.db",
    "price_cache_hours":  4,      # Re-fetch price data after this many hours
    "fundamental_cache_days": 7,  # Fundamentals change slowly
}

# ── Display Settings ─────────────────────────────────────────────────────────
TOP_N_PICKS = 3
APP_TITLE = "NiftyScout"
APP_SUBTITLE = "Daily Top 3 Nifty 50 Picks"
