"""
Scoring Engine
Computes per-stock scores across 4 dimensions and produces a composite ranking.
"""

import numpy as np
import pandas as pd
import pandas_ta as ta

from config import TECH_CONFIG, FUND_CONFIG, RISK_CONFIG, WEIGHTS


def _clamp(val, lo=0, hi=100):
    """Clamp a value between lo and hi."""
    if val is None or np.isnan(val):
        return 50  # Neutral default
    return max(lo, min(hi, val))


# ═══════════════════════════════════════════════════════════════════════════════
# 1. TECHNICAL SCORE
# ═══════════════════════════════════════════════════════════════════════════════

def compute_technical_score(df: pd.DataFrame) -> dict:
    """
    Score 0-100 based on RSI, MACD, MA crossover, volume spike.
    Returns dict with sub-scores and final technical score.
    """
    if df is None or len(df) < 50:
        return {"technical": 50, "rsi": None, "macd_signal": None,
                "ma_crossover": None, "volume_ratio": None}

    close = df["Close"]
    volume = df["Volume"]

    # ── RSI ──────────────────────────────────────────────────────────────
    rsi_series = ta.rsi(close, length=TECH_CONFIG["rsi_period"])
    rsi = rsi_series.iloc[-1] if rsi_series is not None and len(rsi_series) > 0 else 50

    sweet_lo, sweet_hi = TECH_CONFIG["rsi_sweet_spot"]
    if sweet_lo <= rsi <= sweet_hi:
        rsi_score = 80 + (20 * (1 - abs(rsi - 52.5) / 22.5))  # Peak at ~52.5
    elif rsi < TECH_CONFIG["rsi_oversold"]:
        rsi_score = 70  # Oversold bounce potential
    elif rsi > TECH_CONFIG["rsi_overbought"]:
        rsi_score = 20  # Overbought, risky to enter
    else:
        rsi_score = 50  # Neutral zone

    # ── MACD ─────────────────────────────────────────────────────────────
    macd_df = ta.macd(close, fast=TECH_CONFIG["macd_fast"],
                      slow=TECH_CONFIG["macd_slow"],
                      signal=TECH_CONFIG["macd_signal"])
    if macd_df is not None and len(macd_df) > 1:
        macd_line = macd_df.iloc[-1, 0]
        signal_line = macd_df.iloc[-1, 2]
        histogram = macd_df.iloc[-1, 1]
        prev_histogram = macd_df.iloc[-2, 1]

        # Bullish: MACD above signal, histogram growing
        if macd_line > signal_line and histogram > prev_histogram:
            macd_score = 90
        elif macd_line > signal_line:
            macd_score = 70
        elif histogram > prev_histogram:
            macd_score = 60  # Converging, potential crossover
        else:
            macd_score = 30
        macd_signal_val = "bullish" if macd_line > signal_line else "bearish"
    else:
        macd_score = 50
        macd_signal_val = "neutral"

    # ── Moving Average Crossover ─────────────────────────────────────────
    sma_short = ta.sma(close, length=TECH_CONFIG["sma_short"])
    sma_long = ta.sma(close, length=TECH_CONFIG["sma_long"])

    if sma_short is not None and sma_long is not None and len(sma_short) > 1 and len(sma_long) > 1:
        above_now = sma_short.iloc[-1] > sma_long.iloc[-1]
        above_prev = sma_short.iloc[-2] > sma_long.iloc[-2]

        if above_now and not above_prev:
            ma_score = 95  # Golden crossover just happened!
        elif above_now:
            ma_score = 75  # Uptrend
        elif not above_now and above_prev:
            ma_score = 15  # Death cross
        else:
            ma_score = 35  # Downtrend
        ma_crossover = "bullish" if above_now else "bearish"
    else:
        ma_score = 50
        ma_crossover = "neutral"

    # ── Volume Spike ─────────────────────────────────────────────────────
    avg_volume = volume.rolling(20).mean().iloc[-1]
    current_volume = volume.iloc[-1]
    if avg_volume and avg_volume > 0:
        vol_ratio = current_volume / avg_volume
        if vol_ratio >= TECH_CONFIG["volume_spike_threshold"]:
            vol_score = min(95, 60 + (vol_ratio - 1) * 30)  # Higher volume = higher score
        elif vol_ratio >= 1.0:
            vol_score = 60
        else:
            vol_score = 30  # Below average volume = weak conviction
    else:
        vol_ratio = 1.0
        vol_score = 50

    # ── Composite Technical Score ────────────────────────────────────────
    technical = (rsi_score * 0.3 + macd_score * 0.25 +
                 ma_score * 0.25 + vol_score * 0.2)

    return {
        "technical": round(_clamp(technical), 1),
        "rsi": round(rsi, 1),
        "rsi_score": round(rsi_score, 1),
        "macd_signal": macd_signal_val,
        "macd_score": round(macd_score, 1),
        "ma_crossover": ma_crossover,
        "ma_score": round(ma_score, 1),
        "volume_ratio": round(vol_ratio, 2),
        "volume_score": round(vol_score, 1),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 2. FUNDAMENTAL SCORE
# ═══════════════════════════════════════════════════════════════════════════════

def compute_fundamental_score(fundamentals: dict) -> dict:
    """
    Score 0-100 based on P/E, debt/equity, ROE, growth.
    """
    # ── P/E Score ────────────────────────────────────────────────────────
    pe = fundamentals.get("pe_trailing") or fundamentals.get("pe_forward")
    if pe is not None and pe > 0:
        if pe <= FUND_CONFIG["pe_ideal"]:
            pe_score = 90
        elif pe <= FUND_CONFIG["pe_max"]:
            pe_score = 90 - ((pe - FUND_CONFIG["pe_ideal"]) /
                            (FUND_CONFIG["pe_max"] - FUND_CONFIG["pe_ideal"])) * 60
        else:
            pe_score = 20  # Expensive
    else:
        pe_score = 40  # Missing data, neutral-low

    # ── Debt/Equity Score ────────────────────────────────────────────────
    de = fundamentals.get("debt_to_equity")
    if de is not None:
        de = de / 100 if de > 10 else de  # yfinance sometimes returns as percentage
        if de <= 0.3:
            de_score = 95
        elif de <= 0.7:
            de_score = 80
        elif de <= FUND_CONFIG["debt_equity_max"]:
            de_score = 50
        else:
            de_score = 15
    else:
        de_score = 50

    # ── ROE Score ────────────────────────────────────────────────────────
    roe = fundamentals.get("roe")
    if roe is not None:
        roe_pct = roe * 100 if abs(roe) < 1 else roe
        if roe_pct >= 20:
            roe_score = 90
        elif roe_pct >= 15:
            roe_score = 75
        elif roe_pct >= 10:
            roe_score = 55
        else:
            roe_score = 30
    else:
        roe_score = 50

    # ── Earnings Growth Score ────────────────────────────────────────────
    eg = fundamentals.get("earnings_growth")
    if eg is not None:
        eg_pct = eg * 100 if abs(eg) < 5 else eg
        if eg_pct >= 20:
            growth_score = 90
        elif eg_pct >= 10:
            growth_score = 70
        elif eg_pct >= 0:
            growth_score = 50
        else:
            growth_score = 25  # Negative growth
    else:
        growth_score = 50

    # ── Composite ────────────────────────────────────────────────────────
    fundamental = pe_score * 0.3 + de_score * 0.25 + roe_score * 0.25 + growth_score * 0.2

    return {
        "fundamental": round(_clamp(fundamental), 1),
        "pe": pe,
        "pe_score": round(pe_score, 1),
        "debt_equity": de,
        "de_score": round(de_score, 1),
        "roe": roe,
        "roe_score": round(roe_score, 1),
        "earnings_growth": eg,
        "growth_score": round(growth_score, 1),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 3. INSTITUTIONAL / FLOW SCORE
# ═══════════════════════════════════════════════════════════════════════════════

def compute_institutional_score(df: pd.DataFrame, fundamentals: dict) -> dict:
    """
    Score 0-100 based on delivery percentage proxy and price-volume trend.
    (True FII/DII data requires scraping; we use proxies from available data.)
    """
    if df is None or len(df) < 20:
        return {"institutional": 50, "delivery_proxy": None, "accumulation_signal": "neutral"}

    close = df["Close"]
    volume = df["Volume"]

    # ── Accumulation/Distribution proxy ──────────────────────────────────
    # On-Balance Volume trend as proxy for institutional accumulation
    obv = ta.obv(close, volume)
    if obv is not None and len(obv) > 20:
        obv_sma = obv.rolling(20).mean()
        obv_current = obv.iloc[-1]
        obv_avg = obv_sma.iloc[-1]

        if obv_current > obv_avg * 1.05:
            obv_score = 80
            accumulation = "accumulating"
        elif obv_current > obv_avg:
            obv_score = 65
            accumulation = "mild accumulation"
        elif obv_current < obv_avg * 0.95:
            obv_score = 25
            accumulation = "distributing"
        else:
            obv_score = 45
            accumulation = "neutral"
    else:
        obv_score = 50
        accumulation = "neutral"

    # ── Price trend consistency (institutional preference) ───────────────
    # Institutions prefer consistent uptrends, not spiky
    returns_5d = close.pct_change(5).iloc[-1] if len(close) > 5 else 0
    returns_20d = close.pct_change(20).iloc[-1] if len(close) > 20 else 0

    if returns_5d > 0 and returns_20d > 0:
        trend_score = 80
    elif returns_20d > 0:
        trend_score = 60
    elif returns_5d > 0:
        trend_score = 50
    else:
        trend_score = 30

    # ── Dividend yield bonus (DII/mutual fund preference) ────────────────
    div_yield = fundamentals.get("dividend_yield")
    if div_yield and div_yield > 0.02:
        div_bonus = 15
    elif div_yield and div_yield > 0.01:
        div_bonus = 8
    else:
        div_bonus = 0

    institutional = obv_score * 0.5 + trend_score * 0.5 + div_bonus
    institutional = min(100, institutional)

    return {
        "institutional": round(_clamp(institutional), 1),
        "accumulation_signal": accumulation,
        "obv_score": round(obv_score, 1),
        "trend_score": round(trend_score, 1),
        "returns_5d": round(returns_5d * 100, 2) if returns_5d else 0,
        "returns_20d": round(returns_20d * 100, 2) if returns_20d else 0,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# 4. RISK SCORE (higher = lower risk = better)
# ═══════════════════════════════════════════════════════════════════════════════

def compute_risk_score(df: pd.DataFrame, fundamentals: dict) -> dict:
    """
    Score 0-100 where 100 = lowest risk.
    Based on beta, volatility, drawdown from 52-week high.
    """
    if df is None or len(df) < 20:
        return {"risk": 50, "beta": None, "volatility_pct": None, "drawdown_pct": None}

    close = df["Close"]

    # ── Beta Score ───────────────────────────────────────────────────────
    beta = fundamentals.get("beta")
    if beta is not None:
        ideal_lo, ideal_hi = RISK_CONFIG["ideal_beta"]
        if ideal_lo <= beta <= ideal_hi:
            beta_score = 85
        elif beta < ideal_lo:
            beta_score = 70  # Low beta is okay, just less exciting
        elif beta <= RISK_CONFIG["max_beta"]:
            beta_score = 50
        else:
            beta_score = 20  # Very volatile
    else:
        beta_score = 50

    # ── Volatility Score ─────────────────────────────────────────────────
    daily_returns = close.pct_change().dropna()
    if len(daily_returns) >= RISK_CONFIG["volatility_window"]:
        recent_vol = daily_returns.tail(RISK_CONFIG["volatility_window"]).std() * np.sqrt(252) * 100
        if recent_vol < 15:
            vol_score = 90
        elif recent_vol < 25:
            vol_score = 70
        elif recent_vol < 35:
            vol_score = 45
        else:
            vol_score = 20
    else:
        recent_vol = None
        vol_score = 50

    # ── Drawdown from 52-week high ───────────────────────────────────────
    high_52w = fundamentals.get("52w_high")
    current_price = close.iloc[-1]
    if high_52w and high_52w > 0:
        drawdown = ((high_52w - current_price) / high_52w) * 100
        if drawdown < 5:
            dd_score = 90  # Near highs = strength
        elif drawdown < 10:
            dd_score = 75
        elif drawdown < RISK_CONFIG["max_drawdown_pct"]:
            dd_score = 50
        else:
            dd_score = 20  # Deep drawdown = caution
    else:
        drawdown = None
        dd_score = 50

    risk = beta_score * 0.35 + vol_score * 0.35 + dd_score * 0.30

    return {
        "risk": round(_clamp(risk), 1),
        "beta": beta,
        "beta_score": round(beta_score, 1),
        "volatility_pct": round(recent_vol, 1) if recent_vol else None,
        "vol_score": round(vol_score, 1),
        "drawdown_pct": round(drawdown, 1) if drawdown else None,
        "dd_score": round(dd_score, 1),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# COMPOSITE SCORER
# ═══════════════════════════════════════════════════════════════════════════════

def score_stock(ticker: str, price_df: pd.DataFrame, fundamentals: dict) -> dict:
    """
    Compute all 4 dimension scores and the weighted composite.
    Returns a complete scoring dict for one stock.
    """
    tech = compute_technical_score(price_df)
    fund = compute_fundamental_score(fundamentals)
    inst = compute_institutional_score(price_df, fundamentals)
    risk = compute_risk_score(price_df, fundamentals)

    composite = (
        tech["technical"] * WEIGHTS["technical"] +
        fund["fundamental"] * WEIGHTS["fundamental"] +
        inst["institutional"] * WEIGHTS["institutional"] +
        risk["risk"] * WEIGHTS["risk"]
    )

    return {
        "ticker": ticker,
        "name": fundamentals.get("short_name", ticker.replace(".NS", "")),
        "sector": fundamentals.get("sector", "—"),
        "composite": round(composite, 1),
        "technical": tech["technical"],
        "fundamental": fund["fundamental"],
        "institutional": inst["institutional"],
        "risk": risk["risk"],
        "current_price": round(price_df["Close"].iloc[-1], 2) if price_df is not None and len(price_df) > 0 else None,
        "details": {
            "tech": tech,
            "fund": fund,
            "inst": inst,
            "risk": risk,
        },
    }


def rank_stocks(price_data: dict, fundamentals: dict, progress_callback=None) -> list[dict]:
    """
    Score all stocks and return sorted list (best first).
    """
    scores = []
    tickers = list(price_data.keys())
    total = len(tickers)

    for i, ticker in enumerate(tickers):
        if progress_callback:
            progress_callback(i / total, f"Scoring {ticker.replace('.NS', '')}...")
        if ticker in price_data and price_data[ticker] is not None:
            fund = fundamentals.get(ticker, {})
            result = score_stock(ticker, price_data[ticker], fund)
            scores.append(result)

    if progress_callback:
        progress_callback(1.0, "Scoring complete!")

    scores.sort(key=lambda x: x["composite"], reverse=True)
    return scores
