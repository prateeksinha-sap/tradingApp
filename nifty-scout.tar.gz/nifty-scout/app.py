"""
NiftyScout — Streamlit Dashboard
Run with: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime

from config import APP_TITLE, APP_SUBTITLE, TOP_N_PICKS, WEIGHTS, NIFTY_50_TICKERS
from data_fetcher import (
    fetch_price_data, fetch_fundamentals,
    fetch_nifty_index, fetch_india_vix,
    log_picks, get_picks_history,
)
from scoring import rank_stocks


# ── Page Config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title=APP_TITLE,
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 800;
        margin-bottom: 0;
        color: #1a1a2e;
    }
    .sub-header {
        font-size: 1rem;
        color: #666;
        margin-top: -10px;
        margin-bottom: 20px;
    }
    .score-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 12px;
        padding: 20px;
        color: white;
        text-align: center;
    }
    .score-big {
        font-size: 2.5rem;
        font-weight: 900;
    }
    .metric-label {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        opacity: 0.85;
    }
    .pick-rank {
        font-size: 1.1rem;
        font-weight: 700;
        background: #f0f2f6;
        border-radius: 8px;
        padding: 2px 10px;
        display: inline-block;
    }
    div[data-testid="stMetric"] {
        background: #f8f9fa;
        border-radius: 8px;
        padding: 12px;
        border: 1px solid #e9ecef;
    }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"## 🎯 {APP_TITLE}")
    st.caption(APP_SUBTITLE)
    st.divider()

    st.markdown("### ⚙️ Scoring Weights")
    w_tech = st.slider("Technical", 0, 100, int(WEIGHTS["technical"] * 100), 5)
    w_fund = st.slider("Fundamental", 0, 100, int(WEIGHTS["fundamental"] * 100), 5)
    w_inst = st.slider("Institutional", 0, 100, int(WEIGHTS["institutional"] * 100), 5)
    w_risk = st.slider("Low Risk", 0, 100, int(WEIGHTS["risk"] * 100), 5)

    total_w = w_tech + w_fund + w_inst + w_risk
    if total_w > 0:
        WEIGHTS["technical"] = w_tech / total_w
        WEIGHTS["fundamental"] = w_fund / total_w
        WEIGHTS["institutional"] = w_inst / total_w
        WEIGHTS["risk"] = w_risk / total_w

    st.caption(f"Normalized: T={WEIGHTS['technical']:.0%} F={WEIGHTS['fundamental']:.0%} "
               f"I={WEIGHTS['institutional']:.0%} R={WEIGHTS['risk']:.0%}")

    st.divider()
    top_n = st.number_input("Top N Picks", 1, 10, TOP_N_PICKS)

    st.divider()
    st.markdown("### 📊 Market Context")
    show_market = st.checkbox("Show market overview", value=True)

    st.divider()
    if st.button("🗑️ Clear Cache & Refresh", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

    st.divider()
    st.caption("⚠️ **Disclaimer**: This is a decision-support tool, not financial advice. "
               "Always do your own research before investing.")


# ── Header ───────────────────────────────────────────────────────────────────
st.markdown(f'<div class="main-header">🎯 {APP_TITLE}</div>', unsafe_allow_html=True)
st.markdown(f'<div class="sub-header">{APP_SUBTITLE} · {datetime.now().strftime("%A, %d %B %Y")}</div>',
            unsafe_allow_html=True)


# ── Data Loading ─────────────────────────────────────────────────────────────
@st.cache_data(ttl=3600, show_spinner=False)
def load_all_data():
    """Fetch and cache all data."""
    price_data = fetch_price_data()
    fundamentals = fetch_fundamentals()
    return price_data, fundamentals


with st.status("📡 Loading market data...", expanded=True) as status:
    st.write("Fetching price data for Nifty 50 stocks...")
    price_data, fundamentals = load_all_data()
    st.write(f"✅ Loaded {len(price_data)} stocks")

    st.write("Scoring all stocks...")
    rankings = rank_stocks(price_data, fundamentals)
    st.write(f"✅ Scored {len(rankings)} stocks")

    top_picks = rankings[:top_n]
    log_picks(top_picks)
    status.update(label="✅ Analysis complete!", state="complete", expanded=False)


# ── Market Context Panel ─────────────────────────────────────────────────────
if show_market:
    st.markdown("---")
    st.markdown("### 📈 Market Overview")

    col_nifty, col_vix, col_top, col_bottom = st.columns(4)

    nifty_df = fetch_nifty_index()
    if len(nifty_df) > 1:
        nifty_now = nifty_df["Close"].iloc[-1]
        nifty_prev = nifty_df["Close"].iloc[-2]
        nifty_chg = ((nifty_now - nifty_prev) / nifty_prev) * 100
        col_nifty.metric("Nifty 50", f"{nifty_now:,.0f}", f"{nifty_chg:+.2f}%")
    else:
        col_nifty.metric("Nifty 50", "N/A")

    vix_df = fetch_india_vix()
    if len(vix_df) > 0:
        vix_val = vix_df["Close"].iloc[-1]
        vix_label = "Low Fear" if vix_val < 15 else ("Moderate" if vix_val < 20 else "High Fear")
        col_vix.metric("India VIX", f"{vix_val:.1f}", vix_label)
    else:
        col_vix.metric("India VIX", "N/A")

    # Best and worst stock today
    if rankings:
        best = rankings[0]
        worst = rankings[-1]
        col_top.metric("🏆 Top Score", best["name"], f"{best['composite']:.0f}/100")
        col_bottom.metric("📉 Lowest Score", worst["name"], f"{worst['composite']:.0f}/100")


# ── TOP PICKS ────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown(f"### 🏆 Today's Top {top_n} Picks")

if not top_picks:
    st.error("No stocks could be scored. Check your internet connection and try again.")
    st.stop()

# Pick cards
pick_cols = st.columns(top_n)
for i, pick in enumerate(top_picks):
    with pick_cols[i]:
        rank_emoji = ["🥇", "🥈", "🥉"][i] if i < 3 else f"#{i+1}"
        st.markdown(f"#### {rank_emoji} {pick['name']}")
        st.caption(f"{pick['ticker'].replace('.NS', '')} · {pick['sector']}")

        # Composite score
        st.metric("Composite Score", f"{pick['composite']:.0f}/100",
                  label_visibility="visible")

        if pick["current_price"]:
            st.metric("Price", f"₹{pick['current_price']:,.2f}")

        # Sub-scores
        sub_col1, sub_col2 = st.columns(2)
        sub_col1.metric("Technical", f"{pick['technical']:.0f}")
        sub_col2.metric("Fundamental", f"{pick['fundamental']:.0f}")
        sub_col1.metric("Institutional", f"{pick['institutional']:.0f}")
        sub_col2.metric("Risk Safety", f"{pick['risk']:.0f}")


# ── Score Breakdown Radar Chart ──────────────────────────────────────────────
st.markdown("---")
st.markdown("### 📊 Score Breakdown")

fig_radar = go.Figure()
categories = ["Technical", "Fundamental", "Institutional", "Risk Safety"]

for pick in top_picks:
    values = [pick["technical"], pick["fundamental"],
              pick["institutional"], pick["risk"]]
    fig_radar.add_trace(go.Scatterpolar(
        r=values + [values[0]],  # Close the polygon
        theta=categories + [categories[0]],
        fill="toself",
        name=pick["name"],
        opacity=0.6,
    ))

fig_radar.update_layout(
    polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
    showlegend=True,
    height=450,
    margin=dict(l=60, r=60, t=40, b=40),
)
st.plotly_chart(fig_radar, use_container_width=True)


# ── Detailed Charts for Each Pick ────────────────────────────────────────────
st.markdown("---")
st.markdown("### 📈 Price & Volume Charts")

for pick in top_picks:
    ticker = pick["ticker"]
    if ticker not in price_data:
        continue

    df = price_data[ticker]
    with st.expander(f"📊 {pick['name']} ({ticker.replace('.NS', '')})", expanded=(pick == top_picks[0])):

        # Price + Volume chart
        fig = make_subplots(rows=2, cols=1, shared_xaxes=True,
                           row_heights=[0.7, 0.3],
                           vertical_spacing=0.05)

        # Candlestick
        fig.add_trace(go.Candlestick(
            x=df.index, open=df["Open"], high=df["High"],
            low=df["Low"], close=df["Close"],
            name="Price", showlegend=False,
        ), row=1, col=1)

        # 20-day SMA
        sma20 = df["Close"].rolling(20).mean()
        fig.add_trace(go.Scatter(
            x=df.index, y=sma20, name="SMA 20",
            line=dict(color="orange", width=1.5),
        ), row=1, col=1)

        # 50-day SMA
        sma50 = df["Close"].rolling(50).mean()
        fig.add_trace(go.Scatter(
            x=df.index, y=sma50, name="SMA 50",
            line=dict(color="blue", width=1.5),
        ), row=1, col=1)

        # Volume bars
        colors = ["#26a69a" if c >= o else "#ef5350"
                  for c, o in zip(df["Close"], df["Open"])]
        fig.add_trace(go.Bar(
            x=df.index, y=df["Volume"], name="Volume",
            marker_color=colors, showlegend=False,
        ), row=2, col=1)

        fig.update_layout(
            height=500,
            xaxis_rangeslider_visible=False,
            margin=dict(l=0, r=0, t=30, b=0),
            legend=dict(orientation="h", yanchor="bottom", y=1.02),
        )
        fig.update_xaxes(type="category", nticks=10, row=2, col=1)
        st.plotly_chart(fig, use_container_width=True)

        # Detailed scores table
        details = pick["details"]
        detail_data = {
            "Indicator": [
                "RSI", "MACD Signal", "MA Crossover", "Volume Ratio",
                "P/E", "Debt/Equity", "ROE", "Earnings Growth",
                "Accumulation", "5D Return", "20D Return",
                "Beta", "Volatility", "Drawdown from 52W High",
            ],
            "Value": [
                f"{details['tech'].get('rsi', 'N/A')}",
                details["tech"].get("macd_signal", "N/A"),
                details["tech"].get("ma_crossover", "N/A"),
                f"{details['tech'].get('volume_ratio', 'N/A')}x",
                f"{details['fund'].get('pe', 'N/A')}",
                f"{details['fund'].get('debt_equity', 'N/A')}",
                f"{details['fund'].get('roe', 'N/A')}",
                f"{details['fund'].get('earnings_growth', 'N/A')}",
                details["inst"].get("accumulation_signal", "N/A"),
                f"{details['inst'].get('returns_5d', 'N/A')}%",
                f"{details['inst'].get('returns_20d', 'N/A')}%",
                f"{details['risk'].get('beta', 'N/A')}",
                f"{details['risk'].get('volatility_pct', 'N/A')}%",
                f"{details['risk'].get('drawdown_pct', 'N/A')}%",
            ],
            "Score": [
                details["tech"].get("rsi_score", "—"),
                details["tech"].get("macd_score", "—"),
                details["tech"].get("ma_score", "—"),
                details["tech"].get("volume_score", "—"),
                details["fund"].get("pe_score", "—"),
                details["fund"].get("de_score", "—"),
                details["fund"].get("roe_score", "—"),
                details["fund"].get("growth_score", "—"),
                details["inst"].get("obv_score", "—"),
                details["inst"].get("trend_score", "—"),
                "—",
                details["risk"].get("beta_score", "—"),
                details["risk"].get("vol_score", "—"),
                details["risk"].get("dd_score", "—"),
            ],
        }
        st.dataframe(pd.DataFrame(detail_data), hide_index=True, use_container_width=True)


# ── Full Rankings Table ──────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 📋 Full Rankings")

rankings_df = pd.DataFrame([{
    "Rank": i + 1,
    "Stock": r["name"],
    "Ticker": r["ticker"].replace(".NS", ""),
    "Sector": r["sector"],
    "Price": f"₹{r['current_price']:,.2f}" if r["current_price"] else "—",
    "Composite": r["composite"],
    "Technical": r["technical"],
    "Fundamental": r["fundamental"],
    "Institutional": r["institutional"],
    "Risk Safety": r["risk"],
} for i, r in enumerate(rankings)])

st.dataframe(
    rankings_df,
    hide_index=True,
    use_container_width=True,
    column_config={
        "Composite": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f"),
        "Technical": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f"),
        "Fundamental": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f"),
        "Institutional": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f"),
        "Risk Safety": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.0f"),
    }
)


# ── Historical Picks Log ────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 📜 Past Picks History")
history = get_picks_history(days=30)
if len(history) > 0:
    history["ticker"] = history["ticker"].str.replace(".NS", "", regex=False)
    st.dataframe(history, hide_index=True, use_container_width=True)
else:
    st.info("No historical picks yet. Run the analysis daily to build your track record!")


# ── Footer ───────────────────────────────────────────────────────────────────
st.markdown("---")
st.caption(
    f"🎯 NiftyScout · Data via Yahoo Finance (EOD) · "
    f"Last run: {datetime.now().strftime('%Y-%m-%d %H:%M')} · "
    f"Not financial advice — always DYOR"
)
